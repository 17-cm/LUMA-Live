// =========================================================================
// 【模块二·社区子文档1·今日热搜与热点广场】LIVE/社区/module_trends.js
// 样板原封不动注入版
// =========================================================================

var api = window.api || {};
let currentHotSearchTab = 'ranking';
let currentHotSearchFilter = '';
let trendsVirtualScrollerInstance = null;

// 兼容旧调用
function switchHotTrendTab(tabType) {
  if (tabType === 'feed') {
    renderTrends();
    const feedList = document.getElementById('weiboPostFeedContainerFull');
    if (feedList && feedList.scrollIntoView) {
      feedList.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  } else {
    renderHotSearchRanking();
  }
}
window.switchHotTrendTab = switchHotTrendTab;

// 热搜刷新：调用API生成新帖子
let isRefreshingTrends = false;
async function refreshTrendsWithAI(baseNow) {
  if (isRefreshingTrends) return;
  isRefreshingTrends = true;
  if (window.api && api.ui && api.ui.toast) api.ui.toast('正在生成热搜新动态…');
  if (typeof window.toggleBtnLoading === 'function') {
    window.toggleBtnLoading(document.getElementById('btnRefreshTrends'), true);
  }
  const refNow = baseNow && typeof baseNow === 'number' && baseNow > 0 ? baseNow : Date.now();

  try {
    let contextText = '平台目前没有正在直播的主播，请生成包含主播八卦、日常随笔与全网热点的动态。';
    let targetCharId = null;
    try {
      const sessions = await api.db.list('live_sessions', { limit: 500 }) || [];
      const active = sessions.filter(s => s && s.name);
      if (active.length > 0) {
        const picked = active[Math.floor(Math.random() * active.length)];
        targetCharId = picked.characterId || null;
        const duration = picked.startTime ? Math.floor((Date.now() - picked.startTime) / 60000) : 0;
        contextText = `当前主播【${picked.name}】正在直播中，赛道：${picked.category || '日常'}（${picked.subTag || '闲聊'}），标题：${picked.topic || '无标题'}，已播${duration}分钟，热度${picked.heat || 0}。请以此为背景，并结合其他主播日常生活、热搜吃瓜与全网爆梗，生成3条仿微博热搜帖子。`;
      } else if (window.allCharacters && window.allCharacters.length > 0) {
        const pickedChar = window.allCharacters[Math.floor(Math.random() * window.allCharacters.length)];
        targetCharId = pickedChar.id;
        contextText = `参考平台主播【${pickedChar.name}】（赛道标签：${(pickedChar.tags || []).join(' ')}），结合主播与用户的日常互动、赛博热点与全网八卦，生成3条仿微博热搜帖子。`;
      }
    } catch (e) {}

    const res = await window.aiGenerate({
      characterId: targetCharId,
      appTags: ['trends', 'post'],
      instruction: contextText
    });

    const parsed = window.extractJsonFromText ? window.extractJsonFromText(res.text) : null;
    let postList = [];
    if (parsed) {
      if (Array.isArray(parsed.posts) && parsed.posts.length > 0) {
        postList = parsed.posts;
      } else if (Array.isArray(parsed) && parsed.length > 0) {
        postList = parsed;
      } else if (parsed.content) {
        postList = [parsed];
      }
    }

    if (!postList || postList.length === 0) {
      if (window.api && api.ui && api.ui.toast) api.ui.toast('生成格式异常，请重试');
      return;
    }

    const mediaAccounts = ['星芒吃瓜周刊', '赛博娱乐前线', '直播圈内君', '热搜挖掘机', 'LUMA速报', '吃瓜课代表', '赛博八卦侦探', '圈内大表哥'];
    const badgePool = ['娱乐速报', '数码博主', '吃瓜大队长', '知名大V', '热搜爆料官', '游戏先锋', '头条主编'];
    const ipPool = ['北京', '上海', '广东', '浙江', '四川', '江苏', '山东', '赛博星云'];

    if (!window.weiboPosts) window.weiboPosts = [];

    for (let i = 0; i < postList.length; i++) {
      const p = postList[i];
      if (!p || !p.content) continue;

      const accountName = p.mediaName || mediaAccounts[Math.floor(Math.random() * mediaAccounts.length)];
      const badge = p.badge || badgePool[Math.floor(Math.random() * badgePool.length)];
      
      const postTimestamp = refNow - (i * 3 * 60 * 1000) - Math.floor(Math.random() * 8 * 60 * 1000); // 以基准时间递减分布，保证帖子排序真实合理
      
      const commentTree = Array.isArray(p.comments) ? p.comments.map((c, cIdx) => {
        const commentTs = window.TimeKeeper ? window.TimeKeeper.generateCausalChildTimestamp(postTimestamp, cIdx, p.comments.length) : (postTimestamp + (cIdx + 1) * 30000);
        return {
          id: `c_${Date.now()}_${i}_${cIdx}`,
          user: c.user || `网友_${Math.floor(Math.random() * 9000 + 1000)}`,
          avatar: (typeof window.getAvatar === 'function') ? window.getAvatar(c.user || `网友_${cIdx}`, 'first') : '',
          text: c.text || '围观打卡！',
          createdAt: commentTs,
          time: window.formatDynamicTime ? window.formatDynamicTime(commentTs) : '刚刚',
          ip: c.ip || ipPool[Math.floor(Math.random() * ipPool.length)],
          likes: typeof c.likes === 'number' ? c.likes : Math.floor(Math.random() * 200 + 5),
          isLiked: false,
          replies: []
        };
      }) : [];

      const rawStats = p.stats || {};
      const stats = {
        reposts: typeof rawStats.reposts === 'number' ? rawStats.reposts : Math.floor(Math.random() * 1500 + 120),
        comments: typeof rawStats.comments === 'number' ? rawStats.comments : (commentTree.length > 0 ? Math.floor(Math.random() * 3000 + commentTree.length * 100) : Math.floor(Math.random() * 2000 + 300)),
        likes: typeof rawStats.likes === 'number' ? rawStats.likes : Math.floor(Math.random() * 20000 + 2500),
        isLiked: false,
        isDownloaded: false
      };

      // 提取或组装生图提示词（确保每条帖子都能拿到高质量英文提示词调用生图API）
      let imgPrompt = p.imagePrompt || p.image_prompt || p.imgPrompt || p.prompt || '';
      if (!imgPrompt && p.content) {
        imgPrompt = `anime style masterpiece, social media trending scene, live stream screenshot, ${p.tag || '#热搜#'}, ${p.content.slice(0, 45)}, vivid aesthetic lighting, high quality`;
      }

      // 生成或适配动态配图：优先调用生图API
      let postImage = p.image || '';
      if (!postImage && imgPrompt && typeof window.aiGenerateImage === 'function') {
        try {
          const imgRes = await window.aiGenerateImage({ prompt: imgPrompt });
          if (imgRes) {
            postImage = imgRes.dataUrl || imgRes.imageUrl || imgRes.url || (typeof imgRes === 'string' ? imgRes : '');
          }
        } catch (err) {
          console.warn(`第 ${i + 1} 条动态生图API调用失败:`, err);
        }
      }

      // 仅当生图API报错或未返回时，才启用纯本地Canvas生成切片配图作为兜底（无外部URL）
      if (!postImage) {
        try {
          const cvs = document.createElement('canvas');
          cvs.width = 800;
          cvs.height = 450;
          const ctx = cvs.getContext('2d');
          
          const gradients = [
            ['#0f172a', '#1e293b', '#334155', '#f43f5e'],
            ['#18181b', '#27272a', '#3f3f46', '#8b5cf6'],
            ['#1e1b4b', '#312e81', '#4338ca', '#06b6d4'],
            ['#4c0519', '#881337', '#9f1239', '#fbbf24'],
            ['#022c22', '#064e3b', '#047857', '#10b981'],
            ['#1c1917', '#292524', '#44403c', '#ec4899']
          ];
          const gColors = gradients[(i + Math.floor(Math.random() * 2)) % gradients.length];
          const bgGrad = ctx.createLinearGradient(0, 0, 800, 450);
          bgGrad.addColorStop(0, gColors[0]);
          bgGrad.addColorStop(0.5, gColors[1]);
          bgGrad.addColorStop(1, gColors[2]);
          ctx.fillStyle = bgGrad;
          ctx.fillRect(0, 0, 800, 450);

          ctx.strokeStyle = 'rgba(255, 255, 255, 0.07)';
          ctx.lineWidth = 1.5;
          for (let l = 0; l < 8; l++) {
            ctx.beginPath();
            ctx.moveTo(0, l * 65);
            ctx.lineTo(800, l * 65 + 50);
            ctx.stroke();
          }

          const radGrad = ctx.createRadialGradient(400, 225, 20, 400, 225, 380);
          radGrad.addColorStop(0, gColors[3] + '40');
          radGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = radGrad;
          ctx.fillRect(0, 0, 800, 450);

          ctx.fillStyle = gColors[3];
          const bx = 40, by = 40, bw = 140, bh = 36, br = 18;
          ctx.beginPath();
          if (ctx.roundRect) {
            ctx.roundRect(bx, by, bw, bh, br);
          } else {
            ctx.moveTo(bx + br, by);
            ctx.lineTo(bx + bw - br, by);
            ctx.quadraticCurveTo(bx + bw, by, bx + bw, by + br);
            ctx.lineTo(bx + bw, by + bh - br);
            ctx.quadraticCurveTo(bx + bw, by + bh, bx + bw - br, by + bh);
            ctx.lineTo(bx + br, by + bh);
            ctx.quadraticCurveTo(bx, by + bh, bx, by + bh - br);
            ctx.lineTo(bx, by + br);
            ctx.quadraticCurveTo(bx, by, bx + br, by);
            ctx.closePath();
          }
          ctx.fill();

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 16px sans-serif';
          ctx.fillText('LIVE 切片', 66, 64);

          const displayTag = p.tag || (p.topic ? `#${p.topic.replace(/#/g, '')}#` : '#热搜头条#');
          ctx.fillStyle = gColors[3];
          ctx.font = 'bold 22px sans-serif';
          ctx.fillText(displayTag, 40, 135);

          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 28px sans-serif';
          const summaryText = String(p.content || '').replace(/\n/g, ' ');
          ctx.fillText(summaryText.slice(0, 18), 40, 195);
          if (summaryText.length > 18) {
            ctx.fillText(summaryText.slice(18, 36) + (summaryText.length > 36 ? '...' : ''), 40, 245);
          }

          ctx.fillStyle = 'rgba(255, 255, 255, 0.65)';
          ctx.font = '18px sans-serif';
          ctx.fillText(`@${accountName} · LUMA 社交广场独家热点`, 40, 395);

          postImage = cvs.toDataURL('image/jpeg', 0.85);
        } catch (err) {}
      }

      const newPost = {
        id: 'post_ai_' + Date.now() + '_' + i,
        author: {
          name: accountName,
          avatar: (typeof window.getAvatar === 'function') ? window.getAvatar(accountName, 'emoji') : '',
          badge: badge,
          verified: true
        },
        createdAt: postTimestamp,
        time: window.formatDynamicTime ? window.formatDynamicTime(postTimestamp) : '刚刚',
        tag: p.tag || (p.topic ? `#${p.topic.replace(/#/g, '')}#` : '#微博热搜#'),
        mention: p.mention || '',
        linkText: p.linkText || '',
        clipText: p.clipText || '',
        content: p.content,
        image: postImage,
        stats: stats,
        commentTree: commentTree
      };

      // 内存去重
      const exIdx = window.weiboPosts.findIndex(item => item.id === newPost.id);
      if (exIdx >= 0) {
        window.weiboPosts[exIdx] = newPost;
      } else {
        window.weiboPosts.unshift(newPost);
      }
      
      // 持久化到 app_posts 表（安全 upsert，避免重复记录）
      try {
        if (typeof window.persistPostToDb === 'function') {
          await window.persistPostToDb(newPost);
        } else {
          await api.db.create('app_posts', newPost).catch(async () => {
            await api.db.update('app_posts', newPost.id, newPost).catch(() => {});
          });
        }
      } catch (e) {}
    }

    // 上限裁剪：超出 MAX_WEIBO_POSTS 的最旧帖子自动覆盖清理
    if (typeof window.trimWeiboPosts === 'function') {
      await window.trimWeiboPosts();
    }

    renderHotSearchRanking();
    renderTrends();
    if (window.api && api.ui && api.ui.toast) api.ui.toast(`已成功生成 ${postList.length} 条热搜动态`);
  } catch (e) {
    if (window.api && api.ui && api.ui.toast) api.ui.toast('生成失败：' + (e.message || '未知错误'));
  } finally {
    isRefreshingTrends = false;
    if (typeof window.toggleBtnLoading === 'function') {
      window.toggleBtnLoading(document.getElementById('btnRefreshTrends'), false);
    }
  }
}
window.refreshTrendsWithAI = refreshTrendsWithAI;

// 置顶热搜数据管理
const HERO_STORAGE_KEY = 'luma_hero_hot_search';
const DEFAULT_HERO_DATA = {
  image: 'https://picui.ogmua.cn/s1/20260831/de8088ce8dc216b76510f2ebb8630297.jpg',
  title: '主播连麦当场破防！神秘神豪连续狂砸5个嘉年华瞬间反超',
  heat: '389.2万',
  discussions: '5000+'
};

let cachedHeroData = null;

async function loadHeroData() {
  try {
    if (window.api && api.db && api.db.get) {
      const saved = await api.db.get('app_config', 'hero_hot_search');
      if (saved) {
        cachedHeroData = { ...DEFAULT_HERO_DATA, ...saved };
        return cachedHeroData;
      }
    }
  } catch (e) {}
  try {
    const saved = localStorage.getItem(HERO_STORAGE_KEY);
    if (saved) {
      cachedHeroData = { ...DEFAULT_HERO_DATA, ...JSON.parse(saved) };
      return cachedHeroData;
    }
  } catch (e) {}
  cachedHeroData = { ...DEFAULT_HERO_DATA };
  return cachedHeroData;
}

function getHeroData() {
  return cachedHeroData || { ...DEFAULT_HERO_DATA };
}

async function saveHeroData(data) {
  cachedHeroData = { ...DEFAULT_HERO_DATA, ...data };
  try {
    if (window.api && api.db) {
      await dbUpsert('app_config', 'hero_hot_search', data);
    }
    localStorage.setItem(HERO_STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.warn("[saveHeroData] failed:", e);
  }
}

// 置顶热搜编辑模式
let heroEditMode = false;

function enterHeroEdit() {
  heroEditMode = true;
  renderHotSearchRanking();
}
window.enterHeroEdit = enterHeroEdit;

function cancelHeroEdit() {
  heroEditMode = false;
  renderHotSearchRanking();
}
window.cancelHeroEdit = cancelHeroEdit;

async function saveHeroEdit() {
  const titleEl = document.getElementById('heroEditTitle');
  const heatEl = document.getElementById('heroEditHeat');
  const discEl = document.getElementById('heroEditDisc');
  const imgEl = document.getElementById('heroEditImg');
  const data = {
    title: titleEl ? titleEl.value.trim() || DEFAULT_HERO_DATA.title : DEFAULT_HERO_DATA.title,
    heat: heatEl ? heatEl.value.trim() || DEFAULT_HERO_DATA.heat : DEFAULT_HERO_DATA.heat,
    discussions: discEl ? discEl.value.trim() || DEFAULT_HERO_DATA.discussions : DEFAULT_HERO_DATA.discussions,
    image: imgEl ? imgEl.src : DEFAULT_HERO_DATA.image
  };
  await saveHeroData(data);
  heroEditMode = false;
  renderHotSearchRanking();
  if (window.api && api.ui && api.ui.toast) api.ui.toast('置顶热搜已保存');
}
window.saveHeroEdit = saveHeroEdit;

function handleHeroImageUpload(event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = function(e) {
    const imgEl = document.getElementById('heroEditImg');
    if (imgEl) imgEl.src = e.target.result;
  };
  reader.readAsDataURL(file);
}
window.handleHeroImageUpload = handleHeroImageUpload;

// 渲染热搜 TOP 榜（样板结构：.hero-hot 大图 + .hot-list）
// 热搜编辑模式状态
let hotSearchEditMode = false;


// 热搜列表数据加载与保存
async function loadHotSearchItems() {
  try {
    if (window.api && api.db && api.db.get) {
      const saved = await api.db.get('app_config', 'hot_search_items');
      const list = saved && Array.isArray(saved.list) ? saved.list : (Array.isArray(saved) ? saved : null);
      if (list && list.length > 0) {
        window.HOT_SEARCH_ITEMS = list;
        return;
      }
    }
  } catch (e) {}
  // 默认热搜数据
  if (!window.HOT_SEARCH_ITEMS || window.HOT_SEARCH_ITEMS.length === 0) {
    window.HOT_SEARCH_ITEMS = [
      { rank: 1, title: '赛博歌姬露娜深夜直播破百万', heat: '999万', badge: 'hot', badgeText: '爆' },
      { rank: 2, title: '主播打赏榜一竟是程序员', heat: '856万', badge: 'new', badgeText: '新' },
      { rank: 3, title: '虚拟主播出道即巅峰', heat: '723万', badge: '', badgeText: '' },
      { rank: 4, title: '直播间礼物系统全新升级', heat: '612万', badge: '', badgeText: '' },
      { rank: 5, title: '粉丝守护团招募中', heat: '501万', badge: '', badgeText: '' },
      { rank: 6, title: '今日热搜：谁是下一个顶流', heat: '432万', badge: '', badgeText: '' },
      { rank: 7, title: '超话签到活动开启', heat: '389万', badge: '', badgeText: '' },
      { rank: 8, title: '主播联动夜即将开始', heat: '301万', badge: '', badgeText: '' },
      { rank: 9, title: '平台年度盛典投票中', heat: '256万', badge: '', badgeText: '' },
      { rank: 10, title: '新人主播扶持计划上线', heat: '198万', badge: '', badgeText: '' }
    ];
  }
}

async function saveHotSearchItems() {
  try {
    if (window.api && api.db && window.HOT_SEARCH_ITEMS) {
      await dbUpsert('app_config', 'hot_search_items', { list: window.HOT_SEARCH_ITEMS });
    }
  } catch (e) {}
}

function renderHotSearchRanking() {
  const heroBox = document.getElementById('hotSearchHeroContainer');
  const listBox = document.getElementById('hotSearchRankingContainer');
  if (!listBox) return;
  const items = window.HOT_SEARCH_ITEMS || [];

  // 置顶焦点热搜（大图）—— 支持编辑
  if (heroBox) {
    const hero = getHeroData();
    if (heroEditMode) {
      heroBox.innerHTML = '\
        <div class="hero-hot hero-hot-edit" style="cursor:default;">\
          <div class="hero-edit-img-wrap">\
            <img src="' + hero.image + '" alt="" id="heroEditImg">\
            <label class="hero-upload-btn">\
              <input type="file" accept="image/*" style="display:none;" onchange="handleHeroImageUpload(event)">\
              📷 更换图片\
            </label>\
          </div>\
          <div class="hero-edit-form">\
            <input type="text" id="heroEditTitle" value="' + hero.title.replace(/"/g, '&quot;') + '" placeholder="热搜标题" class="hero-edit-input">\
            <div class="hero-edit-row">\
              <input type="text" id="heroEditHeat" value="' + hero.heat + '" placeholder="热度" class="hero-edit-input-sm">\
              <input type="text" id="heroEditDisc" value="' + hero.discussions + '" placeholder="讨论数" class="hero-edit-input-sm">\
            </div>\
            <div class="hero-edit-actions">\
              <button onclick="saveHeroEdit()" class="hero-save-btn">保存</button>\
              <button onclick="cancelHeroEdit()" class="hero-cancel-btn">取消</button>\
            </div>\
          </div>\
        </div>\
      ';
    } else {
      heroBox.innerHTML = '\
        <div class="hero-hot" style="cursor:default;">\
          <img src="' + hero.image + '" alt="">\
          <div class="scrim"></div>\
          <div class="content">\
            <div style="display:flex;justify-content:space-between;align-items:center;">\
              <span class="pin-badge">📌 置顶热搜</span>\
              <button onclick="enterHeroEdit()" class="hero-edit-btn" title="编辑置顶热搜">\
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:14px;height:14px;"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>\
              </button>\
            </div>\
            <div>\
              <div class="title">' + hero.title + '</div>\
              <div class="meta"><span>🔥 ' + hero.heat + ' 热度</span><span>' + hero.discussions + ' 讨论</span></div>\
            </div>\
          </div>\
        </div>\
      ';
    }
  }

  // 热搜榜单（.hot-list）
  listBox.innerHTML = '<div class="hot-list">' +
    items.map((item, idx) => {
      const rankClass = idx === 0 ? 'r1' : idx === 1 ? 'r2' : idx === 2 ? 'r3' : 'rn';
      const badgeHtml = item.badge ? '<span class="hot-badge ' + item.badge + '">' + item.badgeText + '</span>' : '';
      // 编辑模式下标题变成可编辑input
      const titleHtml = hotSearchEditMode
        ? '<input class="hot-edit-input" data-idx="' + idx + '" value="' + item.title.replace(/"/g, '&quot;') + '" style="width:100%;border:1px solid #3B82F6;border-radius:6px;padding:4px 8px;font-size:13px;font-weight:600;background:#EFF6FF;outline:none;">'
        : '<span>' + item.title + '</span> ' + badgeHtml;
      return '\
      <div class="hot-item" style="cursor:default;">\
        <span class="hot-rank ' + rankClass + '">' + item.rank + '</span>\
        <div class="hot-info">\
          <div class="title">' + titleHtml + '</div>\
          <div class="heat">' + item.heat + ' 讨论</div>\
        </div>\
      </div>';
    }).join('') +
    '</div>';

  // 编辑模式下绑定input事件
  if (hotSearchEditMode) {
    setTimeout(() => {
      document.querySelectorAll('.hot-edit-input').forEach(input => {
        input.addEventListener('blur', function() {
          const idx = parseInt(this.dataset.idx);
          if (window.HOT_SEARCH_ITEMS && window.HOT_SEARCH_ITEMS[idx]) {
            window.HOT_SEARCH_ITEMS[idx].title = this.value;
            saveHotSearchItems();
          }
        });
        input.addEventListener('keydown', function(e) {
          if (e.key === 'Enter') this.blur();
        });
      });
    }, 10);
  }
}
window.renderHotSearchRanking = renderHotSearchRanking;

// 切换热搜编辑模式
function toggleHotSearchEdit() {
  const wasEditMode = hotSearchEditMode;
  hotSearchEditMode = !hotSearchEditMode;
  renderHotSearchRanking();
  // 铅笔图标样式切换
  const btn = document.getElementById('hotSearchEditBtn');
  if (btn) {
    if (hotSearchEditMode) {
      btn.style.opacity = '1';
      btn.style.color = '#3B82F6';
      btn.style.transform = 'rotate(-15deg)';
    } else {
      btn.style.opacity = '.5';
      btn.style.color = 'inherit';
      btn.style.transform = 'rotate(0)';
    }
  }
  // 退出编辑模式时主动保存词条和分类
  if (wasEditMode && !hotSearchEditMode) {
    if (typeof saveHotSearchItems === 'function') saveHotSearchItems();
    if (typeof saveHotCategories === 'function') saveHotCategories();
  }
  if (window.api && api.ui && api.ui.toast) {
    api.ui.toast(hotSearchEditMode ? '编辑模式：点击词条可修改' : '热搜已保存');
  }
}
window.toggleHotSearchEdit = toggleHotSearchEdit;

// （铅笔按钮点击事件通过HTML onclick绑定，无需动态绑定）

// 筛选词条
function filterHotSearchTopic(topicTag) {
  currentHotSearchFilter = topicTag;
  renderTrends();
  const feedList = document.getElementById('weiboPostFeedContainerFull');
  if (feedList && feedList.scrollIntoView) {
    feedList.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
}
window.filterHotSearchTopic = filterHotSearchTopic;

function clearHotSearchFilter() {
  currentHotSearchFilter = '';
  renderTrends();
}
window.clearHotSearchFilter = clearHotSearchFilter;

// 单条动态卡片 HTML（样板 .post-card 结构，内联文本流）
function getPostCardHtml(post) {
  // 头像：统一走 getPostAuthorAvatar，优先展示存储的规范头像（角色/用户/随机人物各自独立），保证与详情页一致
  const avatarSrc = (typeof window.getPostAuthorAvatar === 'function')
    ? window.getPostAuthorAvatar(post)
    : ((typeof window.getAvatar === 'function')
        ? window.getAvatar(post.author.name, 'emoji')
        : (post.author.avatar || ''));
  // 手机型号：Float
  const deviceTag = (typeof window.getFloatClientTag === 'function')
    ? window.getFloatClientTag(true)
    : 'Float 客户端';

  // 内联文本流
  const tagHtml = post.tag
    ? '<span class="tag" data-post-tag>' + post.tag + '</span>'
    : '';
  const mentionHtml = post.mention
    ? '<span class="mention" data-post-mention>' + post.mention + '</span>'
    : '';
  const contentHtml = '<span data-post-content>' + (post.content || '') + '</span>';
  const linkHtml = post.linkText
    ? '<span class="link" data-post-link>' + post.linkText + '</span>'
    : '';
  const clipHtml = post.clipText
    ? '<span class="clip" data-post-clip> ' + post.clipText + '</span>'
    : '';

  // 媒体（16:9 容器）
  const mediaHtml = post.image
    ? '<div class="post-media" data-post-media style="aspect-ratio:16/9;"><img src="' + post.image + '" loading="lazy" style="width:100%;height:100%;object-fit:cover;"></div>'
    : '';

  // 头像
  const avatarInner = avatarSrc
    ? '<img class="avatar" src="' + avatarSrc + '" alt="">'
    : '<div class="avatar" style="display:flex;align-items:center;justify-content:center;background:#EEEDF0;color:#9E9EB2;font-size:14px;font-weight:700;">' + (post.author.name || '?').charAt(0) + '</div>';

  // 验证标
  const verifiedHtml = post.author.verified ? '<span class="verified">V</span>' : '';
  // 徽章
  const badgeHtml = post.author.badge ? '<span class="badge">' + post.author.badge + '</span>' : '';

  // 时间：优先用真实 createdAt 时间戳做动态渲染（随时间推进），无时间戳才回退静态文案
  const timeDisplay = post.createdAt
    ? '<span data-dynamic-time data-ts="' + post.createdAt + '">' + (window.formatDynamicTime ? window.formatDynamicTime(post.createdAt) : '刚刚') + '</span>'
    : (post.time || '刚刚');

  // 下载状态
  const isDownloaded = post.stats && post.stats.isDownloaded;

  return '\
    <article class="post-card cursor-pointer" data-post-id="' + post.id + '" onclick="openTrendDetail(\'' + post.id + '\')">\
      <div class="post-head">\
        <div class="author">\
          <div class="avatar-wrap">' + avatarInner + verifiedHtml + '</div>\
          <div class="author-info">\
            <div class="name-row">\
              <span class="name">' + post.author.name + '</span>' + badgeHtml + '\
            </div>\
            <div class="time">' + timeDisplay + ' · 来自 ' + deviceTag + '</div>\
          </div>\
        </div>\
        <button class="more-btn" onclick="showPostDeleteMenu(\'' + post.id + '\', event)">\
          <svg class="ic" viewBox="0 0 256 256" fill="currentColor"><path d="M216,48H176V40a24,24,0,0,0-24-24H104A24,24,0,0,0,80,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM96,40a8,8,0,0,1,8-8h48a8,8,0,0,1,8,8v8H96Zm96,168H64V64H192Z"/></svg>\
        </button>\
      </div>\
      <div class="post-body">\
        <p class="post-text">' + tagHtml + mentionHtml + contentHtml + linkHtml + clipHtml + '</p>' + mediaHtml + '\
      </div>\
      <div class="action-bar" onclick="event.stopPropagation()">\
        <button class="action-btn" data-action="share" onclick="handlePostAction(\'' + post.id + '\', \'repost\')">\
          <svg class="ic" viewBox="0 0 256 256" fill="currentColor"><path d="M176,160a39.89,39.89,0,0,0-28.62,12.09l-46.1-29.63a39.8,39.8,0,0,0,0-28.92l46.1-29.63a40,40,0,1,0-8.66-13.45l-46.1,29.63a40,40,0,1,0,0,55.82l46.1,29.63A40,40,0,1,0,176,160Z"/></svg>\
          <span data-stat="reposts">' + post.stats.reposts + '</span>\
        </button>\
        <button class="action-btn" data-action="comment" onclick="openTrendDetail(\'' + post.id + '\')">\
          <svg class="ic" viewBox="0 0 256 256" fill="currentColor"><path d="M216,48H40A16,16,0,0,0,24,64V224a15.85,15.85,0,0,0,9.24,14.5A16.13,16.13,0,0,0,40,240a15.89,15.89,0,0,0,10.25-3.78L83,208H216a16,16,0,0,0,16-16V64A16,16,0,0,0,216,48Z"/></svg>\
          <span data-stat="comments">' + post.stats.comments + '</span>\
        </button>\
        <button class="action-btn ' + (post.stats.isLiked ? 'liked' : '') + '" data-action="like" onclick="handlePostAction(\'' + post.id + '\', \'like\')">\
          <svg class="ic" viewBox="0 0 256 256" fill="currentColor"><path d="M234,80.12A24,24,0,0,0,216,72H160V56a40,40,0,0,0-40-40,8,8,0,0,0-7.16,4.42L75.06,96H32a16,16,0,0,0-16,16v88a16,16,0,0,0,16,16H204a24,24,0,0,0,23.82-21l12-96A24,24,0,0,0,234,80.12Z"/></svg>\
          <span data-stat="likes">' + post.stats.likes + '</span>\
        </button>\
        <button class="action-btn ' + (isDownloaded ? 'liked' : '') + '" data-action="download" onclick="handlePostAction(\'' + post.id + '\', \'download\')">\
          <svg class="ic" viewBox="0 0 256 256" fill="none" stroke="currentColor" stroke-width="16" stroke-linecap="round" stroke-linejoin="round"><path d="M216,152v48a16,16,0,0,1-16,16H56a16,16,0,0,1-16-16V152"/><path d="M128,24v128"/><polyline points="88,112 128,152 168,112"/></svg>\
        </button>\
      </div>\
    </article>';
}

// 判断帖子是否属于某个热搜话题
function matchesHotTopicFilter(post, tagFilter) {
  if (!tagFilter) return true;
  const core = String(tagFilter).replace(/#/g, '').trim();
  if (!core) return true;
  const haystack = [post.tag, post.content, post.mention].filter(Boolean).join(' ');
  if (haystack.includes(core)) return true;
  const postTagCore = String(post.tag || '').replace(/#/g, '').trim();
  if (postTagCore && (postTagCore.includes(core) || core.includes(postTagCore))) return true;
  return false;
}

// 渲染动态流
function renderTrends() {
  const container = document.getElementById('flow');
  const target = document.getElementById('weiboPostFeedContainerFull');
  const banner = document.getElementById('activeTopicBanner');
  if (!container || !target) return;

  const allPosts = window.weiboPosts || [];
  let displayPosts = allPosts;

  if (currentHotSearchFilter) {
    if (banner) banner.classList.remove('hidden');
    const tagText = document.getElementById('activeTopicTagText');
    if (tagText) tagText.textContent = '当前话题: ' + currentHotSearchFilter;
    displayPosts = allPosts.filter(p => matchesHotTopicFilter(p, currentHotSearchFilter));
  } else {
    if (banner) banner.classList.add('hidden');
  }

  if (displayPosts.length === 0) {
    if (currentHotSearchFilter) {
      if (banner) banner.classList.remove('hidden');
      const tip = document.getElementById('activeTopicTipText');
      if (tip) tip.textContent = '该话题暂无专属动态，已为你展示全网热点';
      displayPosts = allPosts;
    }
    if (displayPosts.length === 0) {
      target.innerHTML = '<div style="background:#fff;border-radius:16px;padding:24px;text-align:center;font-size:12px;color:#9E9EB2;">暂无该话题的动态，快来发布第一条吧～</div>';
      return;
    }
  }

  // 直接渲染（不用虚拟滚动，样板原封不动）
  target.innerHTML = displayPosts.map(item => getPostCardHtml(item)).join('');
}
window.renderTrends = renderTrends;

// 分类切换
document.addEventListener('DOMContentLoaded', function() {
  const catRail = document.getElementById('hotCatRail');
  if (catRail) {
    catRail.querySelectorAll('.cat-chip').forEach(c => {
      c.onclick = function() {
        catRail.querySelectorAll('.cat-chip').forEach(x => x.classList.remove('on'));
        c.classList.add('on');
        if (window.api && api.ui && api.ui.toast) api.ui.toast('切换到「' + c.textContent.trim() + '」');
      };
    });
  }
});

// 帖子删除菜单
function showPostDeleteMenu(postId, event) {
  event.stopPropagation();
  // 移除已存在的菜单
  const oldMenu = document.getElementById('postDeleteMenu');
  if (oldMenu) oldMenu.remove();

  // 找到帖子卡片
  const card = event.target.closest('.post-card');
  if (!card) return;

  const menu = document.createElement('div');
  menu.id = 'postDeleteMenu';
  menu.style.cssText = 'position:absolute;z-index:10;top:44px;right:10px;background:#fff;border-radius:10px;box-shadow:0 4px 16px rgba(0,0,0,.12);padding:4px;min-width:80px;';
  menu.innerHTML = '<button style="display:block;width:100%;padding:8px 14px;border:0;background:none;color:#F43F5E;font-size:13px;font-weight:600;text-align:center;cursor:pointer;border-radius:8px;" onmouseover="this.style.background=\'#FFF1F2\'" onmouseout="this.style.background=\'none\'" onclick="deletePost(\'' + postId + '\')">删除</button>';

  card.appendChild(menu);

  // 点击其他地方关闭
  setTimeout(() => {
    document.addEventListener('click', function closeMenu(e) {
      if (!menu.contains(e.target)) {
        menu.remove();
        document.removeEventListener('click', closeMenu);
      }
    });
  }, 10);
}
window.showPostDeleteMenu = showPostDeleteMenu;

// 删除帖子
function deletePost(postId) {
  const menu = document.getElementById('postDeleteMenu');
  if (menu) menu.remove();

  if (window.weiboPosts) {
    const idx = window.weiboPosts.findIndex(p => p.id === postId);
    if (idx > -1) {
      window.weiboPosts.splice(idx, 1);
    }
  }

  // 同步删除 DB 持久化记录，确保退出 APP 后删除的帖子不再恢复
  if (typeof window.deletePostFromDb === 'function') {
    window.deletePostFromDb(postId);
  } else if (window.api && api.db && typeof api.db.delete === 'function') {
    try { api.db.delete('app_posts', postId); } catch (e) {}
  }

  renderTrends();
  if (window.api && api.ui && api.ui.toast) api.ui.toast('帖子已删除');
}
window.deletePost = deletePost;




// =========================================================================
// 热搜分类（与热搜榜共用小铅笔，编辑模式下边框变蓝可点击修改）
// =========================================================================
const DEFAULT_HOT_CATEGORIES = ['实时', '娱乐', '科技', '体育', '游戏', '音乐', '影视'];
let hotCategories = [...DEFAULT_HOT_CATEGORIES];

async function loadHotCategories() {
  try {
    if (window.api && api.db && api.db.get) {
      const saved = await api.db.get('app_config', 'hot_categories');
      const list = saved && Array.isArray(saved.list) ? saved.list : (Array.isArray(saved) ? saved : null);
      if (list && list.length > 0) {
        hotCategories = list;
      }
    }
  } catch (e) {}
  renderHotCatChips();
}

async function saveHotCategories() {
  try {
    if (window.api && api.db) {
      await dbUpsert('app_config', 'hot_categories', { list: hotCategories });
    }
  } catch (e) {}
}

function renderHotCatChips() {
  const container = document.getElementById('hotCatChips');
  if (!container) return;
  
  const editMode = hotSearchEditMode;
  
  if (editMode) {
    // 编辑模式：每个分类变成可点击编辑的按钮（边框变蓝）
    container.innerHTML = hotCategories.map((cat, idx) => 
      '<button class="cat-chip cat-editable" data-idx="' + idx + '" style="border:1px solid #3B82F6;color:#3B82F6;background:#EFF6FF;">' + cat + '</button>'
    ).join('');
    // 绑定点击编辑
    container.querySelectorAll('.cat-editable').forEach(btn => {
      btn.addEventListener('click', function() {
        const idx = parseInt(this.dataset.idx);
        const currentVal = hotCategories[idx];
        const input = document.createElement('input');
        input.type = 'text';
        input.value = currentVal;
        input.style.cssText = 'width:60px;text-align:center;border:1px solid #3B82F6;border-radius:9999px;padding:4px 8px;font-size:12px;outline:none;background:#fff;';
        this.replaceWith(input);
        input.focus();
        input.select();
        const save = () => {
          const newVal = input.value.trim();
          if (newVal) {
            hotCategories[idx] = newVal;
            saveHotCategories();
          }
          renderHotCatChips();
        };
        input.addEventListener('blur', save);
        input.addEventListener('keydown', function(e) {
          if (e.key === 'Enter') input.blur();
        });
      });
    });
  } else {
    // 正常模式：显示按钮（极细边框）
    container.innerHTML = hotCategories.map((cat, idx) => 
      '<button class="cat-chip' + (idx === 0 ? ' on' : '') + '" onclick="selectHotCategory(' + idx + ')">' + cat + '</button>'
    ).join('');
  }
}

function selectHotCategory(idx) {
  document.querySelectorAll('#hotCatChips .cat-chip').forEach((b, i) => {
    b.classList.toggle('on', i === idx);
  });
}

// 修改 toggleHotSearchEdit：同时控制 tag 编辑
const _origToggleHotSearchEdit = toggleHotSearchEdit;
window.toggleHotSearchEdit = function() {
  _origToggleHotSearchEdit();
  // 延迟渲染 tag，因为 _origToggleHotSearchEdit 里会先 renderHotSearchRanking
  setTimeout(renderHotCatChips, 50);
};

// 初始化：加载数据
(async function initHotSearchData() {
  await loadHeroData();
  await loadHotSearchItems();
  await loadHotCategories();
  renderHotSearchRanking();
})();
