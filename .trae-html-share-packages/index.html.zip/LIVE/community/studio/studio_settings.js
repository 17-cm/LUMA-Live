(function () {
  'use strict';

  var LIVE_SETTINGS_KEY = 'live_video_gallery';

  window.renderLiveSettings = async function () {
    var area = document.getElementById('liveSettingsModuleArea');
    if (!area) return;

    area.innerHTML = '';

    var header = document.createElement('div');
    header.className = 'p-4 bg-gradient-to-br from-violet-500 via-purple-600 to-indigo-700 rounded-3xl text-white shadow-md space-y-2';
    header.innerHTML =
      '<div class="flex items-center gap-2">' +
        '<span class="text-base">&#x1F3AC;</span>' +
        '<h4 class="text-sm font-black">直播画面背景</h4>' +
      '</div>' +
      '<p class="text-xs text-purple-100 leading-relaxed">选择主播，上传视频作为直播间全屏背景。每位主播最多 3 个视频。</p>';
    area.appendChild(header);

    var charSection = document.createElement('div');
    charSection.className = 'luxe-card p-3 bg-white';
    charSection.innerHTML =
      '<label class="text-[10px] font-bold text-slate-500 mb-2 block">选择主播</label>' +
      '<div class="flex gap-2 overflow-x-auto no-scrollbar pb-1" id="liveSettingsCharList"><div class="text-[11px] text-slate-400 py-4 text-center w-full">加载中…</div></div>';
    area.appendChild(charSection);

    // 直播间音乐 入口卡
    var musicCard = document.createElement('div');
    musicCard.className = 'luxe-card p-3 bg-white active:scale-[0.99] transition cursor-pointer';
    musicCard.onclick = function () { if (typeof window.openLiveMusicSubPage === 'function') window.openLiveMusicSubPage(); };
    musicCard.innerHTML =
      '<div class="flex items-center gap-3">' +
        '<div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-fuchsia-500 via-pink-500 to-rose-500 flex items-center justify-center shadow-md flex-shrink-0">' +
          '<svg class="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor"><path d="M9 18V5l12-2v13"></path><circle cx="6" cy="18" r="3"></circle><circle cx="18" cy="16" r="3"></circle></svg>' +
        '</div>' +
        '<div class="flex-1 min-w-0">' +
          '<div class="flex items-center gap-1.5">' +
            '<h4 class="text-sm font-black text-slate-900">直播间音乐</h4>' +
            '<span class="text-[9px] bg-fuchsia-100 text-fuchsia-700 px-1.5 py-0.5 rounded-full font-bold">BETA</span>' +
          '</div>' +
          '<p class="text-[11px] text-slate-500 mt-0.5">管理歌单，让直播更有氛围</p>' +
        '</div>' +
        '<svg class="w-4 h-4 text-slate-300 flex-shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>' +
      '</div>';
    area.appendChild(musicCard);

    // 直播粉丝增长区间 设置卡（排在音乐按键下方）
    area.appendChild(buildFansGrowthSettingCard());

    try {
      var chars = window.api && window.api.characters && window.api.characters.list ? await window.api.characters.list() : [];
      renderCharList(chars);
    } catch (e) {
      var cl = document.getElementById('liveSettingsCharList');
      if (cl) cl.innerHTML = '<div class="text-[11px] text-slate-400 py-4 text-center w-full">加载失败，请重试</div>';
    }
  };

  function renderCharList(chars) {
    var container = document.getElementById('liveSettingsCharList');
    if (!container) return;
    if (!chars || chars.length === 0) {
      container.innerHTML = '<div class="text-[11px] text-slate-400 py-4 text-center w-full">暂无主播</div>';
      return;
    }
    container.innerHTML = chars.map(function (c) {
      var avatar = c.avatar || '';
      return '<div onclick="showLiveSettingsUploadSheet(\'' + c.id + '\',\'' + (c.name || c.id).replace(/'/g, "\\'") + '\')" class="flex-shrink-0 w-16 text-center cursor-pointer active:scale-95 transition">' +
        '<div class="w-14 h-14 mx-auto rounded-full overflow-hidden ring-1 ring-slate-200">' +
          '<img src="' + avatar + '" class="w-full h-full object-cover">' +
        '</div>' +
        '<span class="text-[10px] font-bold text-slate-700 mt-1 block truncate">' + (c.name || c.id) + '</span>' +
      '</div>';
    }).join('');
  }

  // 直播粉丝增长区间设置卡：每场直播结束按区间随机增粉（默认 1000-5000）
  function buildFansGrowthSettingCard() {
    var p = window.appParams || {};
    var range = window.LiveStatsManager && window.LiveStatsManager.getGainRange
      ? window.LiveStatsManager.getGainRange()
      : { min: 1000, max: 5000 };
    var minVal = Number(p.fansGainMin) || range.min;
    var maxVal = Number(p.fansGainMax) || range.max;

    var card = document.createElement('div');
    card.className = 'luxe-card p-3 bg-white space-y-2.5';
    card.id = 'fansGrowthSettingCard';
    card.innerHTML =
      '<div class="flex items-center gap-3">' +
        '<div class="w-11 h-11 rounded-2xl bg-gradient-to-br from-rose-500 via-orange-500 to-amber-500 flex items-center justify-center shadow-md flex-shrink-0">' +
          '<svg class="w-5 h-5 text-white" viewBox="0 0 24 24" fill="currentColor"><path d="M3 22v-4a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v4"></path><circle cx="9" cy="8" r="3.5"></circle><path d="M17 11.2a3.5 3.5 0 1 0-2.4-.2"></path><path d="M17 14v4"></path><path d="M15 16h4"></path></svg>' +
        '</div>' +
        '<div class="flex-1 min-w-0">' +
          '<div class="flex items-center gap-1.5">' +
            '<h4 class="text-sm font-black text-slate-900">直播粉丝增长</h4>' +
            '<span class="text-[9px] bg-rose-50 text-rose-600 px-1.5 py-0.5 rounded-full font-bold">结算联动</span>' +
          '</div>' +
          '<p class="text-[11px] text-slate-500 mt-0.5">每场直播结束后，按区间随机增长的粉丝数量</p>' +
        '</div>' +
      '</div>' +
      '<div class="h-[1px] bg-slate-100"></div>' +
      '<div class="flex items-center gap-2.5" id="fansGrowthRangeInputs">' +
        '<div class="flex-1">' +
          '<label class="text-[10px] font-bold text-slate-500 block mb-1">最低增粉</label>' +
          '<input type="number" id="fansGainMin" min="0" value="' + minVal + '" class="input-ins !py-2 text-center text-xs font-bold">' +
        '</div>' +
        '<span class="text-slate-300 font-black text-sm pt-5">~</span>' +
        '<div class="flex-1">' +
          '<label class="text-[10px] font-bold text-slate-500 block mb-1">最高增粉</label>' +
          '<input type="number" id="fansGainMax" min="0" value="' + maxVal + '" class="input-ins !py-2 text-center text-xs font-bold">' +
        '</div>' +
      '</div>' +
      '<button onclick="saveFansGrowthSetting()" class="btn-brand w-full py-2 justify-center text-xs font-bold shadow-sm">' +
        '<span>保存粉丝增长区间</span>' +
      '</button>';

    // 输入限幅：避免最高被拉低到低于最低
    var minInput = card.querySelector('#fansGainMin');
    var maxInput = card.querySelector('#fansGainMax');
    if (minInput) minInput.oninput = function () {
      if (maxInput && Number(maxInput.value) < Number(minInput.value)) maxInput.value = minInput.value;
    };
    if (maxInput) maxInput.oninput = function () {
      if (minInput && Number(minInput.value) > Number(maxInput.value)) maxInput.value = minInput.value;
    };

    return card;
  }
  window.buildFansGrowthSettingCard = buildFansGrowthSettingCard;

  // 保存粉丝增长区间到宿主持久库（app_settings.global_params）
  async function saveFansGrowthSetting() {
    var minEl = document.getElementById('fansGainMin');
    var maxEl = document.getElementById('fansGainMax');
    if (!minEl || !maxEl) return;

    var min = Math.max(0, Math.floor(Number(minEl.value)));
    var max = Math.max(min, Math.floor(Number(maxEl.value) > 0 ? Number(maxEl.value) : min));
    if (min > max) { var t = min; min = max; max = t; }

    if (!window.appParams) window.appParams = {};
    window.appParams.fansGainMin = min;
    window.appParams.fansGainMax = max;

    try {
      await dbUpsert('app_settings', 'global_params', window.appParams);
      if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('直播粉丝增长区间已保存：' + min + ' ~ ' + max);
    } catch (e) {
      if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('保存成功：' + min + ' ~ ' + max);
    }
  }
  window.saveFansGrowthSetting = saveFansGrowthSetting;

  window.showLiveSettingsUploadSheet = function (charId, charName) {
    var overlay = document.getElementById('liveSettingsUploadSheet');
    if (overlay) overlay.remove();

    overlay = document.createElement('div');
    overlay.id = 'liveSettingsUploadSheet';
    overlay.className = 'fixed inset-0 z-[9999] flex items-center justify-center px-4';
    overlay.style.backgroundColor = 'rgba(0,0,0,0.45)';
    overlay.style.paddingTop = 'var(--ai-phone-app-safe-top, 88px)';
    overlay.style.paddingBottom = 'var(--ai-phone-app-safe-bottom, 24px)';
    overlay.onclick = function (e) { if (e.target === overlay) overlay.remove(); };

    var sheet = document.createElement('div');
    sheet.className = 'w-full max-w-[400px] bg-white rounded-3xl px-6 pt-6 pb-7 space-y-4 shadow-2xl';
    sheet.innerHTML =
      '<h4 class="text-base font-black text-slate-900 text-center">为 ' + charName + ' 上传视频</h4>' +
      '<p class="text-[11px] text-slate-500 text-center leading-relaxed">请选择一段不超过 30 秒的视频作为直播间全屏背景</p>' +
      '<div class="flex gap-3 pt-2">' +
        '<button id="lsUploadCancelBtn" class="flex-1 min-h-[44px] py-3 rounded-2xl bg-slate-100 text-slate-600 text-xs font-bold active:scale-95 transition">取消</button>' +
        '<button id="lsUploadConfirmBtn" class="flex-1 min-h-[44px] py-3 rounded-2xl bg-gradient-to-r from-violet-500 to-indigo-600 text-white text-xs font-bold shadow-md active:scale-95 transition">上传</button>' +
      '</div>';

    overlay.appendChild(sheet);
    document.body.appendChild(overlay);

    document.getElementById('lsUploadCancelBtn').onclick = function () { overlay.remove(); };
    document.getElementById('lsUploadConfirmBtn').onclick = function () {
      startUpload(charId, charName, overlay);
    };
  };

  async function startUpload(charId, charName, sheetOverlay) {
    var data = await loadVideoGallery(charId);
    if (data.videos.length >= 3) {
      if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('每位主播最多上传 3 个视频');
      return;
    }

    try {
      var picked = window.api && window.api.media && window.api.media.pick ? await window.api.media.pick({ accept: 'video/*' }) : null;
      if (!picked || !picked.file || !picked.file.dataUrl) {
        if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('未选择视频');
        return;
      }

      var dataUrl = picked.file.dataUrl;

      var valid = await checkVideoDuration(dataUrl);
      if (!valid) {
        if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('视频时长超过 30 秒，请选择更短的视频');
        return;
      }

      var stored = window.api && window.api.media && window.api.media.put ? await window.api.media.put({ dataUrl: dataUrl }) : null;
      if (!stored || !stored.ref) {
        if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('视频上传失败');
        return;
      }

      data.videos.push({ ref: stored.ref, mime: stored.mime || 'video/mp4', uploadedAt: Date.now() });
      await saveVideoGallery(charId, data);

      if (sheetOverlay) sheetOverlay.remove();

      if (window.api && window.api.ui && window.api.ui.toast) {
        window.api.ui.toast('已上传至 ' + charName + ' 主页相册，可前往查看，或在直播间点击「画面比例」切换');
      }
    } catch (e) {
      console.error('[liveSettings] upload error:', e);
      if (window.api && window.api.ui && window.api.ui.toast) window.api.ui.toast('上传失败，请重试');
    }
  }

  function checkVideoDuration(dataUrl) {
    return new Promise(function (resolve) {
      var video = document.createElement('video');
      video.preload = 'metadata';
      video.onloadedmetadata = function () {
        var dur = video.duration;
        video.remove();
        resolve(dur <= 31);
      };
      video.onerror = function () {
        video.remove();
        resolve(true);
      };
      video.src = dataUrl;
    });
  }

  async function loadVideoGallery(charId) {
    try {
      var data = window.api && window.api.db && window.api.db.get ? await window.api.db.get(LIVE_SETTINGS_KEY, charId) : null;
      return data || { videos: [] };
    } catch (e) {
      return { videos: [] };
    }
  }

  async function saveVideoGallery(charId, data) {
    if (window.api && window.api.db) {
      var existing = await window.api.db.get(LIVE_SETTINGS_KEY, charId).catch(function () { return null; });
      if (existing) {
        await window.api.db.update(LIVE_SETTINGS_KEY, charId, data);
      } else {
        await window.api.db.create(LIVE_SETTINGS_KEY, { id: charId, videos: data.videos || [] });
      }
    }
  }

  window.getLiveSettingsVideoGallery = async function (charId) {
    return loadVideoGallery(charId);
  };
})();